package com.oracle.flightservice.controller;

import java.util.List;

public class UserList {
    private List<Integer> users;

    public List<Integer> getUsers() {
        return users;
    }

    public void setUsers(List<Integer> users) {
        this.users = users;
    }

}
